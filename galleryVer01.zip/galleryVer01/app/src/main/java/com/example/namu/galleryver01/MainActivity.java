package com.example.namu.galleryver01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    ImageView imageView02 ;
    ImageView imageView03;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        imageView02 = findViewById(R.id.imageView02);
        imageView03 = findViewById(R.id.imageView03);

        //String url = "https://i.pinimg.com/originals/f5/05/ec/f505ec4a493959f044923174e92d7b79.jpg";

        Glide.with(this)
                .load("http://via.placeholder.com/300.png")
                .placeholder(R.drawable.image_loading)
                .error(R.drawable.image_break)
                .into(imageView);

        Glide.with(this)
                .load("https://i.pinimg.com/originals/f5/05/ec/f505ec4a493959f044923174e92d7b79.jpg")
                .into(imageView);

        Glide.with(this)
                .load("http://via.placeholder.com/300.png")
                .placeholder(R.drawable.image_loading)
                .error(R.drawable.image_break)
                .into(imageView02);

        Glide.with(this)
                .load("https://kenh14cdn.com/2018/3/25/c820e2ce8b0935c083357d958d6b0579-1521987239451345799146.jpg")
                .into(imageView02);

        Glide.with(this)
                .load("http://via.placeholder.com/300.png")
                .placeholder(R.drawable.image_loading)
                .error(R.drawable.image_break)
                .into(imageView03);

        Glide.with(this)
                .load("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSclE520de3-E4CV98ExkCKDhPLK5zkmV4CRb2GXzXSe-7URPHO")
                .into(imageView03);

    }

}
